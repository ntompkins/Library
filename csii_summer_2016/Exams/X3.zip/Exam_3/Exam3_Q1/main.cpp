/*
Exam 3 - Question 1
-------------------
1.a) Consider the function
        void change (int *p) {*p =20;}
    Show how to call the change function so that it sets the integer variable int i; to 20.

1.b) Consider the function
        void modify (int &x) {x = 10;}
    Show how to call the modify function so that it sets the integer variable int i; to 10.

1.c) Write a function whose prototype is:
        void exchange (int *p, int *q);
    that takes two pointers to integer variables and exchanges the values in those variables.
	Show how to call the exchange function to exchange the values in variables int x=10; int y=20;

1.d) Write a function whose prototype is:
        void swapEnds (vector<int> &v);
    that is passed a reference to a vector.  The function swaps the values in the first and last 
	entries of the vector if the size of the vector is greater than 1.  Show how to create a vector 
	containing integer values 4,7,1,2,7 and call the swapEnds function.

1.e) Write a function whose prototype is:
        char lastChar (const char *s);
    that takes a C-string as a parameter and returns the last character in the string 
	or a null (\0) if the C-string is empty.  Show how to call the lastChar function 
	with a string containing "abcdez". 
*/
#include <iostream>
#include <iomanip>
#include <string>
#include <cstring>
#include <vector>

using namespace std;

// Question 1.a
void change (int *p) {*p = 20;}
// Question 1.b
void modify (int &x) {x=10;}
// Question 1.c
void exchange(int *first, int *second) {
	int temp = *first;
	*first = *second;
	*second = temp;
}
// Question 1.d
void swapEnds(vector<int> &v) {
	if(v.size() > 1) {
		int holder = v.at(0);
		v.at(0) = v.at(v.size() - 1);
		v.at(v.size() - 1) = holder;	
	}
}
// Question 1.e
char lastChar(const char *s) {
	char result;
	//  takes a C-string as a parameter and returns the last character in the string 
	//	or a null (\0) if the C-string is empty.  Show how to call the lastChar function 
	//	with a string containing "abcdez". 
	(sizeof(s) / sizeof(*s) > 1) ? result = s[sizeof(s)/sizeof(*s) - 3] : result = '\0';
	return result;
}
// Question 1.d helper
void show(vector<int> &v) {
	cout << "v=";
	for(int i : v) {
		cout << i << " ";
	}
	cout << endl;
}
// Main
int main(int argc, char** argv) {
	cout << "Exam 3 - Questions 1a-1e" << endl;
	cout << "------------------------" << endl << endl;
	
	int x=0,y=0;
	// Question 1.a
	// code goes here
	change(&x);
	cout << "Question 1a: x=" << x << endl;
	
	// Question 1.b
	// code goes here
	modify(y);
	cout << "Question 1b: y=" << y << endl;
	
	// Question 1.c
	// code goes here
	exchange(&x, &y);
	cout << "Question 1c: x=" << x << ", y=" << y << endl;
	
	// Question 1.d
	vector<int> v = {4, 7, 1, 2, 7};
	// code goes here
	swapEnds(v);
	cout << "Question 1d: ";
	show(v);

	// Question 1.e
	char s[] = "abcdez";
	char ch = '?';
	// code goes here
	ch = lastChar(s);
	cout << "Question 1e: ";
	cout << "s:\"" << s << "\", last character:" << ch << endl;
	
	return 0;
}

