/*
Exam 3 - Question 3
-------------------
Imagine a graphics system that consists of a collection of shapes that must be drawn at certain locations. A base class Shape and its derived classes Rectangle, Square, and Circle currently support construction of the objects and positioning and drawing of specific shapes.

Add a pure virtual function to the Shape base class that calculates and returns the area of the object based upon the object's dimension(s).  The prototype of the function is:
	virtual double area () const = 0;

Add an area () virtual function to each of the derived classes.  The prototype of the function is:
	virtual double area () const;

The function should calculate and return the area of the object.  Modify the output of the test program to display the calculated area.

A starting version of main.cpp is contained in exam3_q3_main.cpp under the Review tab. Submit your answer by attaching your revised main.cpp source file.
*/
#include <iostream>
#include <iomanip>
#include <string>
#include <memory>
#include <vector>
#include <cmath>

using namespace std;

class Shape {
	protected:
		int posX, posY;
	public:
		Shape() {};
		virtual void draw() const = 0;
		// Area
		virtual double area () const = 0;
		
		void draw(int x, int y) {
			posX = x; posY = y;
			draw();
		}
		int getX() const {return posX;}
		int getY() const {return posY;}
		void setPosition(int x, int y) {posX = x; posY = y;}
};
class Square : public Shape {
	private:
		double side;
	public:
		Square () {side=0.0;}
		Square (double s) {side=s;}
		void setSide(double s) {side=s;}
		double getSide() const {return side;}
		// Area
		virtual double area () const {
			return pow(side, 2);
		}
		virtual void draw() const {
			cout << "Drawing square at (" << getX() << "," << getY() << ") ";
			cout << "with side:" << getSide();
			cout << ", area: " << area();
			cout << endl;
		}
};
class Circle : public Shape {
	private:
		const double PI = 3.14159;
		double radius;
	public:
		Circle () {radius=0.0;}
		Circle (double r) {radius=r;}
		void setRadius(double r) {radius=r;}
		double getRadius() const {return radius;}
		// Area
		virtual double area () const {
			return PI * pow(getRadius(), 2);
		} 
		virtual void draw() const {
			cout << "Drawing circle at (" << getX() << "," << getY() << ") ";
			cout << "with radius:" << getRadius();
			cout << ", area: " << area();
			cout << endl;
		}
};
class Rectangle : public Shape {
	private:
		double height, width;
	public:
		Rectangle () {height=width=0.0;}
		Rectangle (double h, double w) {height=h; width=w;}
		void setHeight(double h) {height=h;}
		void setWidth(double w) {width=w;}
		double getHeight() const {return height;}
		double getWidth() const {return width;}
		virtual double area () const {
			return height * width;	
		}
		virtual void draw() const {
			cout << "Drawing rectangle at (" << getX() << "," << getY() << ") ";
			cout << "with height:" << getHeight();
			cout << ", width:" << getWidth();
			cout << ", area " << area();
			cout << endl;
		}
};


//Square::virtual double area () const {}
//Rectangle::virtual double area () const {}

int main() {
	vector<shared_ptr<Shape>> shapes {
		make_shared<Square>(2.5),
		make_shared<Rectangle>(10.25,8.5),
		make_shared<Circle>(2.5)
	};
	cout << "Exam 3 - Question 3" << endl;
	cout << "-------------------" << endl;
	int x=0, y=0;
	for (auto shape : shapes) {
		shape->draw(x+=10,y+=10);
	}
	
	// Display areas
//	for (auto shape : shapes) {
//		shape->area();
//	}
	
	return 0;
}
