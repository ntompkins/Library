#include <iostream>
#include <iomanip>
#include <string>
#include <memory>
#include <vector>

using namespace std;
// Abstract base class (cannot be instantiated)
class Shape {
	protected:
		int posX, posY;
	public:
		Shape() {};
		// Pure virtual function (derived classes must override)
		// Declared with the = 0 notation and no body or definition
		virtual void draw() const = 0;
		void draw(int px, int py) {
			posX = px;
			posY = py;
			draw();
		}
		void setPosition(int px, int py) {posX = px; posY = py;}
};
// Derived class
class Rectangle : public Shape {
	public:
		Rectangle() {posX=posY=0;}
		virtual void draw() const {
			cout << "Drawing rectangle at (" << posX << "," << posY << ")" << endl; 
		}
};
// Derived class
class Hexagon : public Shape {
	public:
		Hexagon() {posX=posY=0;}
		virtual void draw() const {
			cout << "Drawing hexagon at (" << posX << "," << posY << ")" << endl; 
		}
};
// Derived class
class Triangle : public Shape {
	public:
		Triangle() {posX=posY=0;}
		virtual void draw() const {
			cout << "Drawing triangle at (" << posX << "," << posY << ")" << endl; 
		}
};
// Derived class
class Square : public Shape {
	public:
		Square() {posX=posY=0;}
		virtual void draw() const {
			cout << "Drawing square at (" << posX << "," << posY << ")" << endl; 
		}
};
// Derived class
class Circle : public Shape {
	public:
		Circle() {posX=posY=0;}
		virtual void draw() const {
			cout << "Drawing circle at (" << posX << "," << posY << ")" << endl; 
		}
};

int main(int argc, char** argv) {

	// Vector of shapes
	vector<shared_ptr<Shape>> shapes {
		make_shared<Square>(),
		make_shared<Triangle>(),
		make_shared<Hexagon>(),
		make_shared<Rectangle>(),
		make_shared<Circle>()
	};
	cout << "Polymorphism and Virtual Functions" << endl;
	cout << "----------------------------------" << endl;
	int x = 0, y = 0;
	for (auto shape : shapes) {
		shape->draw(x+=10,y+=10);
	}
	return 0;
}
