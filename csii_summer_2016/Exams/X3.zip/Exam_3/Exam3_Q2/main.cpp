/*
Exam 3 - Question 2
-------------------
Imagine a software security system that contains a class Password that supports verification and maintenance of a user password. 
The class contains a member isStrongPassword that insures the following criteria are met when constructing a new object or setting the password in an existing object.

a.	The password must be at least 6 characters long.
b.	The password must contain at least one uppercase and at least one lowercase letter.
c.	The password must contain at least one digit.

Complete the isStrongPassword function. The function has a single string argument and returns true if the string meets the criteria established for a password or false otherwise. 

Write a program that demonstrates usage of the Password class. The program should contain a loop that:
a.	Prompts the user for entry of a password (terminate the program if the user presses the Enter key only).
b.	Creates a new Password object and calls the setPassword member function to store the password in the new object.
c.	Displays an appropriate message stating the setPassword function call return status.

A starting version of main.cpp is contained in exam3_q2_main.cpp under the Review tab. Submit your answer by attaching your revised main.cpp source file.
*/
#include <iostream>
#include <iomanip>
#include <string>
#include <memory>

using namespace std;

class Password {
	private:
		string password;
	public:
		Password() 			{ password=""; }
		Password(string s)	{ password = isStrongPassword(s) ? s : ""; }
		
		string getPassword (){ return password; }
		bool   setPassword (string s) {
			if(isStrongPassword(s)) {
				password = s;
				return true;
			}
			else return false;			
		}
		static bool isStrongPassword(string);
};

static bool isStrongPassword(string);

bool Password::isStrongPassword(string s) {
	bool result,
		 has_up = false, 
		 has_num = false;
	// Check size
	bool is_6 = s.size() >= 6 ? true : false;
	// Check for number and uppercase
	for(char& x : s) {
		if (isdigit(x)) has_num = true;
		if (isupper(x)) has_up  = true;
	}
	// Set result to T or F
	result = (has_up && has_num && is_6);
	return result;
}

int main(int argc, char** argv) {
	cout << "Exam 3 - Question 2" << endl;
	cout << "-------------------" << endl << endl;
	
	std::string usrIn = " ";
	while(usrIn != "") {
		// Get password
		std::cout << "Enter your password: ";
		getline(cin, usrIn);
		// Quit if no string
		if(usrIn != "") {
			// Create object
			Password usrPass(usrIn);
			// Give feedback
			cout << "\nPassword " <<( usrPass.isStrongPassword(usrIn) ? "is " : "is not ") << "strong.\n";
		}
	}
	return 0;
}
